import streamlit as st
import pandas as pd
from chat_parser import parse_chat
from analyzer import analyze_data, plot_most_active_users

# Streamlit app title
st.title("WhatsApp Chat Analyzer")

# Upload file section
uploaded_file = st.file_uploader("Upload your WhatsApp chat file", type='txt')

if uploaded_file is not None:
    file_contents = uploaded_file.read().decode('utf-8')
    
    # Parse the chat data
    df = parse_chat(file_contents)
    
    if df.empty:
        st.warning("No messages found. Please check the chat file format.")
    else:
        st.write("### Parsed Chat Data")
        st.write(df)

        # Perform sentiment analysis
        analyzed_data = analyze_data(df)
        
        st.write("### Sentiment Analysis Results")
        st.write(analyzed_data[['Date', 'User', 'Message', 'Sentiment Score']])

        # Plot most active users
        st.write("### Most Active Users")
        plot_most_active_users(df)
