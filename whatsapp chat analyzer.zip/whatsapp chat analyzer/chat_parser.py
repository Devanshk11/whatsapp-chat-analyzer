import pandas as pd
import re
from datetime import datetime

def parse_chat(file_contents):
    chat_data = []
    lines = file_contents.splitlines()
    for line in lines:
        # Adjust the regex pattern based on your chat format
        match = re.match(r'(\d+/\d+/\d+,\s\d+:\d+\s(AM|PM)) - (.*?): (.*)', line)
        if match:
            date_str, user, message = match.groups()[0], match.groups()[2], match.groups()[3]
            date = datetime.strptime(date_str, '%m/%d/%y, %I:%M %p')
            chat_data.append([date, user, message])
    return pd.DataFrame(chat_data, columns=['Date', 'User', 'Message'])
