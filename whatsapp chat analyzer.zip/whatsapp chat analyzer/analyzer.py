import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from nltk.sentiment import SentimentIntensityAnalyzer
import streamlit as st

def analyze_data(df):
    # Check if the DataFrame has messages
    if df.empty:
        return df  # Return empty DataFrame if no messages
    
    sia = SentimentIntensityAnalyzer()
    df['Sentiment Score'] = df['Message'].apply(lambda x: sia.polarity_scores(x)['compound'])
    return df

def plot_most_active_users(df, top_n=10):
    if df.empty:
        return  # Do not plot if the DataFrame is empty

    user_activity = df['User'].value_counts().head(top_n)  # Limit to top N users
    plt.figure(figsize=(12, 6))  # Increase figure size for better spacing
    sns.barplot(x=user_activity.index, y=user_activity.values, palette='viridis')
    plt.title('Most Active Users', fontsize=16)
    plt.ylabel('Number of Messages', fontsize=12)
    plt.xlabel('Users', fontsize=12)
    plt.xticks(rotation=45, ha='right')  # Rotate x-axis labels for better readability
    
    # Add data labels on top of the bars
    for index, value in enumerate(user_activity.values):
        plt.text(index, value, str(value), ha='center', va='bottom', fontsize=10)

    st.pyplot(plt)  # Use Streamlit's pyplot function to display the plot
    